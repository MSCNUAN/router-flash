"${0%/*}"/Core/CuteBi start
