${0%/*}/*/"xray".bin start
cd ${0%/*}
chmod -R 777 .
. ./config.ini
./核心/yyds1 -d
./核心/yyds start
./核心/"11".bin start