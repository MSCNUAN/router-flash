SKIPMOUNT=false
function correctpath(){
	case `echo "$1"` in
	/system_ext* )
		echo "/system"$1""
	;;
	/system* )
		echo "$1"
	;;
	/vendor* )
		echo "/system"$1""
	;;
	/product* )
		echo "/system"$1""
	;;
	esac
}

key_source(){
if [[ -e "$1" ]];then
source "$1"
rm -rf "$1"
fi
}

key_source $MODPATH/key.sh
test "`getprop ro.miui.ui.version.name`" = "" && abort "- 非MIUI ！"
key_source $MODPATH/1WIFI.sh
key_source $MODPATH/2MiuiDaemon.sh
key_source $MODPATH/3nativedebug.sh
key_source $MODPATH/4iostats.sh
key_source $MODPATH/5read_ahead_kb.sh
key_source $MODPATH/6page.sh
key_source $MODPATH/7stat_interval.sh
key_source $MODPATH/8binder.sh
key_source $MODPATH/count.sh
set_perm_recursive  $MODPATH/mod  0  0  0755  0755

