logdir=/data/vendor/wlan_logs
test -e $logdir && rm -rf $logdir 