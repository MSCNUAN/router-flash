#8. 禁用binder活页夹日志
#* 此功能仅限跟踪应用(测试应用)场景下使用, 
#对普通用户并没有什么用, 同样会产生1%-3%左右的CPU开销

#解决办法:
#使用此命令: echo "0" > /sys/module/binder/parameters/debug_mask
echo -e "\n∞————————————————————————∞"
echo -e "\n－ ☞8. 禁用binder活页夹日志☜"
echo '
set_value() {
    if [[ -f "$2" ]];then
        chmod 0777 "$2" >/dev/null 2>&1
        chmod u+x "$2" >/dev/null 2>&1
        echo "$1" > "$2" && chmod 0644 "$2" >/dev/null 2>&1 || echo "修改"$2"失败！"
    fi
}

set_value "0" /sys/module/binder/parameters/debug_mask
' > $MODPATH/mod/8binder.sh && echo -e "\n- 完成！\n" || echo "\n- 失败！\n"

echo -n  [⑧禁用binder活页夹日志]  >>$TMPDIR/enable.log
