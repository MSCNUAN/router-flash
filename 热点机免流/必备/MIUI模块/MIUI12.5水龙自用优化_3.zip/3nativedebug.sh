#3. 禁用小米内核调试收集服务
#* 此东西/进程对普通用户完全无用, 
#还会使部分情况下存储空间的"其他"占用飙升的问题
#* 脚本位于/ramdisk/init.miui.nativedebug.rc中

#解决办法:
#可以在/system/build.prop末尾添加一行sys.miui.ndcd=off即可禁用
echo -e "\n∞————————————————————————∞"
echo -e "\n－ ☞3. 禁用小米内核调试收集服务☜"
echo 'sys.miui.ndcd=off' >$MODPATH/system.prop && echo -e "\n- 完成！\n" || echo "\n- 失败！\n"

echo -n [③禁用小米内核调试收集服务] >>$TMPDIR/enable.log


