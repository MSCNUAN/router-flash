#7. 调整虚拟内存更新/刷新间隔
#* 频繁更新虚拟内存的状态会在高内存压力下造成性能抖动(轻微的卡顿), 
#所以将其改为10或者20都行

#解决办法:
#使用此命令: echo "10" > /proc/sys/vm/stat_interval

echo -e "\n∞————————————————————————∞"
echo -e "\n－ ☞7. 调整虚拟内存更新/刷新间隔☜"
echo '
set_value() {
    if [[ -f "$2" ]];then
        chmod 0777 "$2" >/dev/null 2>&1
        chmod u+x "$2" >/dev/null 2>&1
        echo "$1" > "$2" && chmod 0644 "$2" >/dev/null 2>&1 || echo "修改"$2"失败！"
    fi
}

set_value "10" /proc/sys/vm/stat_interval
' > $MODPATH/mod/7stat_interval.sh && echo -e "\n- 完成！\n" || echo "\n- 失败！\n"

echo -n [⑦调整虚拟内存更新/刷新间隔] >>$TMPDIR/enable.log

