#5. 更改磁盘I/O预读大小
#* 根据Google的说法
#使用过大的预读会造成很多内存压力
#而且我们的手机存储设备都是固态硬盘
#不会存在寻道导致的响应时间问题

#解决办法:
#echo "128" > /sys/block/sda/queue/read_ahead_kb
#echo "128" > /sys/block/sde/queue/read_ahead_kb
#* eMMC设备使用命令:
#echo "128" > /sys/block/mmcblk0/queue/read_ahead_kb
echo -e "\n∞————————————————————————∞"
echo -e "\n－ ☞5. 更改磁盘I/O预读大小"
echo '
set_value() {
    if [[ -f "$2" ]];then
        chmod 0777 "$2" >/dev/null 2>&1
        chmod u+x "$2" >/dev/null 2>&1
        echo "$1" > "$2" && chmod 0644 "$2" >/dev/null 2>&1 || echo "修改"$2"失败！"
    fi
}
until $(dumpsys deviceidle get screen) ;do
sleep 10
done
a=0
while :;do
set_value "128" /sys/block/sda/queue/read_ahead_kb
set_value "128" /sys/block/sde/queue/read_ahead_kb
set_value "128" /sys/block/mmcblk0/queue/read_ahead_kb
sleep 1m
a=$(($a+1))
test $a == 2 && break
done
' > $MODPATH/mod/5read_ahead_kb.sh && echo -e "\n- 完成！\n" || echo "\n- 失败！\n"

echo -n [⑤更改磁盘I/O预读大小] >>$TMPDIR/enable.log


