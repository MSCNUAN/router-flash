file=$MODPATH/module.prop
mod_info=$(cat $TMPDIR/enable.log )
sed -i "/^description=/ c description=共8项优化。已安装: "$mod_info" " $file


