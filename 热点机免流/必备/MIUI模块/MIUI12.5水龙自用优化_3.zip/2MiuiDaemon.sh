#2. 针对第三方内核的系统处理
#* 如果您正在使用第三方的内核
#且无Xiaomi私有库更改的内核
#最好将MiuiDaemon软件包停用

#apk路径位于: /system/app/MiuiDaemon

#此为MIUI的性能守护进程, 
#负责小米内核mi_reclaim, rtmm, 内核跟踪, migt, 内存扩展以及zram使用率检测等等,
#如果您使用的内核无这些节点则会导致偶现logd疯狂占用CPU
#标记进程: MiSysOpt
#TODO: 部分MIUI移植包sgsi的logd占用高也可以通过此办法解决

echo -e "\n∞————————————————————————∞"
echo -e "\n－ ☞2. 针对第三方内核的系统处理☜"
for file in `find /system /vendor /product /system_ext -iname "MiuiDaemon" -type d 2> /dev/null ` ;do
		dir=$(correctpath $file)
		mkdir -p $MODPATH$dir
		touch $MODPATH$dir/.replace && echo "－ 已创建${file##*/}"
done && echo -e "\n- 完成！\n" || echo "\n- 失败！\n"

echo -n [②MiuiDaemon软件包停用] >>$TMPDIR/enable.log

