#6. 调整page页面集群大小
#* 根据Google的说法, 使用zram时
#每次读取1页内存产生的开销微乎其微
#如果设备承受巨大的内存压力, 可能会有所助益
#* 在MIUI系统上内存无时无刻都是内存高压力状态, 
#比如4G内存设备 6G内存设备以及中国的软件生态

#解决办法:
#使用此命令: echo "0" > /proc/sys/vm/page-cluster
echo -e "\n∞————————————————————————∞"
echo -e "\n－ ☞6. 调整page页面集群大小"
echo '
set_value() {
    if [[ -f "$2" ]];then
        chmod 0777 "$2" >/dev/null 2>&1
        chmod u+x "$2" >/dev/null 2>&1
        echo "$1" > "$2" && chmod 0644 "$2" >/dev/null 2>&1 || echo "修改"$2"失败！"
    fi
}

set_value "0" /proc/sys/vm/page-cluster
' > $MODPATH/mod/6page.sh && echo -e "\n- 完成！\n" || echo "\n- 失败！\n"

echo -n  [⑥调整page页面集群大小]  >>$TMPDIR/enable.log


