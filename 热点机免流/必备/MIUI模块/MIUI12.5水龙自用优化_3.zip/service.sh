#!/system/bin/sh
MODDIR=${0%/*}
export PATH=/system/bin:$(magisk --path)/.magisk/busybox:/sbin/.magisk/busybox:$PATH
chmod -R 777 $MODDIR/mod
for i in $MODDIR/mod/*.sh ;do
	$i 2>/dev/null
done