#4. 禁用收集磁盘I/O读写统计
#* 此功能用于检测磁盘读写状态
#在Android N之后由于SELinux限制
#软件已经无法获取到/proc目录下的所有文件
#默认还会对CPU产生大概1%-3%左右的性能开销占用

#解决办法:
#* UFS设备使用命令:
#echo "0" > /sys/block/sda/queue/iostats
#echo "0" > /sys/block/sde/queue/iostats
#* eMMC设备使用命令:
#echo "0" > /sys/block/mmcblk0/queue/iostats
echo -e "\n∞————————————————————————∞"
echo -e "\n－ ☞4. 禁用收集磁盘I/O读写统计☜"
echo '
set_value() {
    if [[ -f "$2" ]];then
        chmod 0777 "$2" >/dev/null 2>&1
        chmod u+x "$2" >/dev/null 2>&1
        echo "$1" > "$2" && chmod 0644 "$2" >/dev/null 2>&1 || echo "修改"$2"失败！"
    fi
}

set_value "0" /sys/block/sda/queue/iostats
set_value "0" /sys/block/sde/queue/iostats
set_value "0" /sys/block/mmcblk0/queue/iostats
' > $MODPATH/mod/4iostats.sh && echo -e "\n- 完成！\n" || echo "\n- 失败！\n"

echo -n [④禁用收集磁盘I/O读写统计] >>$TMPDIR/enable.log

