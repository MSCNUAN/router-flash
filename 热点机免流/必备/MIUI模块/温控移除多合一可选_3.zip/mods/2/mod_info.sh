mod_name="移除thermalboost参数"
mod_install_desc="
- 这个温控我还不知道是什么，
- 但是移除了貌似会卡顿(负优化)，请自行选择加入"
mod_install_info="是否安装$mod_name"
mod_select_yes_text="安装$mod_name"
mod_select_yes_desc="[$mod_select_yes_text]"
mod_select_no_text="不安装$mod_name"

mod_install_yes(){
	find /system /system_ext /vendor /product -iname 'perf' -type d  2> /dev/null | while read dir ;do
	dir=$(correctpath $dir )
	test -n $dir && mkdir -p $MODPATH$dir
	for file in `find $dir -iname 'thermal*' -type f 2> /dev/null ` ;do
		file=$(correctpath $file )
		mkdir -p $MODPATH${file%/*}
		touch $MODPATH$file && echo -e "——替换 $(basename $file) 文件大小: $(du -sh $file | sed 's/\/.*//g;s/ //g') "
	done
done
return 0
}

mod_install_no(){
return 0
}
