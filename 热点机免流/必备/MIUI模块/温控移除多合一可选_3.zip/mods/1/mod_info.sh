mod_name="移除libthermal参数"
mod_install_desc="
- 有的系统有libthermal参数
- 这个也是温控，但是有人刷了这个可能会卡开机，请自己判断。"
mod_install_info="是否安装$mod_name"
mod_select_yes_text="安装$mod_name"
mod_select_yes_desc="[$mod_select_yes_text]"
mod_select_no_text="不安装$mod_name"

mod_install_yes(){
	find /system /system_ext /vendor /product -iname 'libthermal*' -type f  2> /dev/null | sed '/hardware/d;/android/d' | while read file ;do
	file=$(correctpath $file  )
	test -n $file && {
		mkdir -p $MODPATH${file%/*} && touch $MODPATH$file && echo -e "——替换 $(basename $file) 文件大小: $(du -sh $file | sed 's/\/.*//g;s/ //g') "
	}
done
return 0
}

mod_install_n(){
return 0
}

