mod_name="移除miui云温控"
mod_install_desc="$mod_name"
mod_install_info="是否安装$mod_name"
mod_select_yes_text="安装$mod_name"
mod_select_yes_desc="[$mod_select_yes_text]"
mod_select_no_text="不安装$mod_name"

mod_install_yes(){
	export PATH=/system/bin:$(magisk --path)/.magisk/busybox:$PATH

	test -z "$(getprop ro.miui.ui.version.name)" && echo "非MIUI ！" && exit

	busybox="/data/adb/magisk/busybox"

	test -e $busybox || echo "未找到Magisk的busybox！"

	dir1="/data/vendor/thermal/config"
	dir2="/data/thermal/config"

	alias chattr="/data/adb/magisk/busybox chattr"

	function thermalkill(){
		if test -e ${1%/*};then
			chattr -i -a -A ${1%/*}
			rm -rf ${1%/*}
			touch ${1%/*}
			chmod 000 ${1%/*}
			chattr +i ${1%/*} && echo "屏蔽云温控成功！" || echo "失败！"
		fi
	}


	thermalkill $dir1 2> /dev/null
	thermalkill $dir2 2> /dev/null

	return 0
}

mod_install_no(){
	return 0
}

