mod_name="移除perf参数"
mod_install_desc="
- 性能强劲的可以移除这个，例如835以上的
- 或者有其他调度的，例如yc的uperf 和perfd 调度
- 可以移除
- 因为perf会更改CPU 频率
- 可能会加速耗电，或者使第三方调度失效。
"

mod_install_info="是否安装$mod_name"
mod_select_yes_text="安装$mod_name"
mod_select_yes_desc="[$mod_select_yes_text]"
mod_select_no_text="不安装$mod_name"

mod_install_yes(){
	find /system /system_ext /vendor /product -iname 'perf' -type d  2> /dev/null | while read dir ;do
	dir=$(correctpath $dir )
	test -n $dir && mkdir -p $MODPATH$dir
	for file in `find $dir -type f 2> /dev/null ` ;do
		file=$(correctpath $file )
		mkdir -p $MODPATH${file%/*}
		touch $MODPATH$file && echo -e "——替换 $(basename $file) 文件大小: $(du -sh $file | sed 's/\/.*//g;s/ //g') "
	done
done
return 0
}

mod_install_no(){
return 0
}

