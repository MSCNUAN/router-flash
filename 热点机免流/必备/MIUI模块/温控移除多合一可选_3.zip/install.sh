SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=false

miui_version="`getprop ro.miui.ui.version.name`"
var_soc="`getprop ro.board.platform`"
model="`getprop ro.product.model`"
id="`grep_prop id $TMPDIR/module.prop`"
var_device="`getprop ro.product.device`"
var_version="`getprop ro.build.version.release`"
author="`grep_prop author $TMPDIR/module.prop`"
name="`grep_prop name $TMPDIR/module.prop`"
description="`grep_prop description $TMPDIR/module.prop`"


echo -e  "∞————————————————————————∞"
echo -e  ""
echo -e  "- 您的设备名称: $model"
echo -e  "- 您的设备: $var_device"
echo -e  "- 系统版本: $var_version"
echo -e  "- $name    "
echo -e  "- 作者：$author"
echo -e  "∞————————————————————————∞"
echo -e  ""

initmods() {
	mod_name=""
	mod_install_info=""
	mod_select_yes_text=""
	mod_select_yes_desc=""
	mod_select_no_text=""
	mod_select_no_desc=""
	mod_require_device=""
	mod_require_version=""
	INSTALLED_FUNC="`trim $INSTALLED_FUNC`"
	MOD_SKIP_INSTALL=false
	cd $TMPDIR/mods
}

keytest() {
	echo -e  "∞————————————————————————∞"
	echo -e  ""
	echo -e  "- 音量键测试 -"
	echo -e  "  请按下 [音量+] 键："
	echo -e  "  无反应或传统模式无法正确安装时，请触摸一下屏幕后继续"
	(/system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" > $TMPDIR/events) || return 1
	return 0
}

chooseport() {
	while (true); do
		/system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" > $TMPDIR/events
		if (`cat $TMPDIR/events 2> /dev/null | /system/bin/grep VOLUME > /dev/null`); then
			break
		fi
	done
	if (`cat $TMPDIR/events 2> /dev/null | /system/bin/grep VOLUMEUP > /dev/null`); then
		return 0
	else
		return 1
	fi
}

chooseportold() {
	$KEYCHECK
	$KEYCHECK
	SEL=$?
	if test "$1" == "UP" ; then
		UP=$SEL
	elif [ "$1" == "DOWN" ]; then
		DOWN=$SEL
	elif [ $SEL -eq $UP ]; then
		return 0
	elif [ $SEL -eq $DOWN ]; then
		return 1
	else
		abort "   未检测到音量键!"
	fi
}

on_install() {
	unzip -o "$ZIPFILE" 'mods/*' -d "$TMPDIR/" >&2
	source $TMPDIR/util_funcs.sh
	KEYCHECK=$TMPDIR/keycheck
	chmod 755 $KEYCHECK
	test -e $TMPDIR/cat_mods.sh && source $TMPDIR/cat_mods.sh

	# 测试音量键
	if keytest; then
		VOLKEY_FUNC=chooseport
		echo -e  ""
		echo -e  "∞————————————————————————∞"
		echo -e  ""
	else
		VOLKEY_FUNC=chooseportold
		echo -e  ""
		echo -e  "∞————————————————————————∞"
		echo -e  ""
		echo -e  "- 检测到遗留设备！使用旧的 keycheck 方案 -"
		echo -e  ""
		echo -e  "- 进行音量键录入 -"
		echo -e  ""
		echo -e  "  录入：请按下 [音量+] 键："
		$VOLKEY_FUNC "UP"
		echo -e  "  已录入 [音量+] 键。"
		echo -e  ""
		echo -e  "  录入：请按下 [音量-] 键："
		$VOLKEY_FUNC "DOWN"
		echo -e  "  已录入 [音量-] 键。"
		echo -e  ""
		echo -e  "∞————————————————————————∞"
		echo -e  ""
	fi

	# 替换文件夹列表
	REPLACE=""
	# 已安装模块
	MODS_SELECTED_YES=""
	MODS_SELECTED_NO=""
	# 加载可用模块
	initmods
	for MOD in $(ls)
	do
		if test -f $MOD/mod_info.sh ; then
			MOD_FILES_DIR="$TMPDIR/mods/$MOD/files"
			source $MOD/mod_info.sh

			if test -z $mod_require_device ; then
				mod_require_device=$var_device
			fi

			if test -z $mod_require_version ; then
				mod_require_version=$var_version
			fi

			if $MOD_SKIP_INSTALL ; then
				echo -e  "\n跳过[$mod_name]安装\n"
				initmods
				continue
			fi

			if test "`echo -e  $var_device | egrep $mod_require_device`" = "" ; then
				echo -e  "\n[$mod_name]不支持你的设备。\n"
			elif [ "`echo -e  $var_version | egrep $mod_require_version`" = "" ]; then
				echo -e  "\n[$mod_name]不支持你的系统版本。\n"
			else


				echo -e  "\n○——————————————————————————○\n\n————————☯☯安装【$mod_name】☯☯\n "

				test "$mod_install_desc" != "" && echo -e  "\n————介绍: $mod_install_desc\n"

				test "$mod_install_desc" != "" && echo -e  "\n -🎯🎯🎯 ️️$mod_install_info 🎯🎯🎯-\n"
				
				echo -e  "   🔼[音量+]：$mod_select_yes_text"
				echo -e  "   🔽[音量-]：$mod_select_no_text"
				echo -e "\n○——————————————————————————○ \n "


				if $VOLKEY_FUNC; then
					echo -e  "\n——————————✅✅✅✅\n已选择[$mod_select_yes_text]✔。\n——————————✅✅✅✅\n"
					mod_install_yes
					run_result=$?
					if test $run_result -eq 0 ; then
						MODS_SELECTED_YES="$MODS_SELECTED_YES ($MOD)"
						INSTALLED_FUNC="$mod_select_yes_desc $INSTALLED_FUNC"
					else
						echo -e  "\n😂失败。错误: $run_result\n"
					fi

				else
					echo -e  "\n——————————❌❌❌❌️\n已选择[$mod_select_no_text]✖。\n——————————❌❌❌❌\n"
					
					mod_install_no
					run_result=$?
					if test $run_result -eq 0 ; then
						MODS_SELECTED_NO="$MODS_SELECTED_NO ($MOD)"
						INSTALLED_FUNC="$mod_select_no_desc $INSTALLED_FUNC"
					else
						echo -e  "\n😂失败。错误: $run_result\n"
					fi
				fi
			fi
		else
			return 1
		fi
		initmods
	done

	test -z "$INSTALLED_FUNC" && echo -e "\n—— 🎭🎭🎭未安装任何功能 即将退出安装...\n" && abort 

	echo -e  "description=安装的功能：$INSTALLED_FUNC" >> $TMPDIR/module.prop
}

set_perm_recursive  $MODPATH  0  0  0755  0755

