#!/system/bin/sh

[ "$(id -u)" != "0" ] && echo "请您先授予root 权限，然后再次点击脚本。" && exit

export PATH=/system/bin:$(magisk --path)/.magisk/busybox:$PATH

test -z "$(getprop ro.miui.ui.version.name)" && echo "非MIUI ！" && exit 

busybox="/data/adb/magisk/busybox"

test -e $busybox || echo "未找到Magisk的busybox！"

dir1="/data/vendor/thermal/config"
dir2="/data/thermal/config"

test -z $(which -a chattr) && {
$busybox ln -sf "$busybox" "$busybox/chattr"
alias chattr="$busybox/chattr"
}


function thermalkill(){
if test -e ${1%/*} -a ! -e "$1" ;then
chattr -i -a -A ${1%/*}
rm -rf ${1%/*} && echo "删除云温控成功！" || echo "删除失败！"
fi
}


thermalkill $dir1 2>/dev/null
thermalkill $dir2 2>/dev/null

function recoverycloudthermal(){
am broadcast --user 0 -a update_profile com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
services=`settings get secure enabled_accessibility_services | grep -v 'null'`
service='com.qualcomm.qti.perfdump/com.qualcomm.qti.perfdump.AutoDetectService'
check=$(echo $services | grep $service | wc -l)
if test "$check" -lt "1" ;then
	settings put secure accessibility_enabled 1 
	settings put secure enabled_accessibility_services "$service:$services" 
fi
}
recoverycloudthermal >/dev/null 2>&1 && echo "已经玄学请求云温控！重启看看！" || echo "失败！"
