
id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH=/system/bin:$MODPATH/busybox:$(magisk --path)/.magisk/busybox:$PATH


function show_value() {
	local value=$1
	local file="${MODPATH}/配置.conf"
	cat "${file}" | grep -E "(^$value=)" | sed '/^#/d;/^[[:space:]]*$/d;s/.*=//g' | sed 's/，/,/g;s/——/-/g;s/：/:/g'
}

#删除并且chattr +i 广告文件
function X_file() {
	if test -e "$1"; then
		rm -rf "$1"
		touch "$1"
		chmod 000 "$1"
		chattr +i "$1"
	fi
}

#恢复chattr +i锁定的文件，并且删除
function RE_file() {
	if test -e "$1"; then
		chattr =A "$1"
		chmod 777 "$1"
		rm -rf "$1"
	fi
}

#删除并且用chmod权限锁定文件，效果比chattr要差
function mkdir_file() {
	if test -e "$1"; then
		chattr =A "$1"
		rm -rf "$1"
		mkdir -p "${1%/*}"
		touch "$1"
		chmod 000 "$1"
	fi
}

