#!/system/bin/sh
#脚本来源于搞机助手
#https://t.me/gjzs666
#https://www.igjbbs.cn/threads/77

id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH=/system/bin:$MODPATH/busybox:$(magisk --path)/.magisk/busybox:$PATH


test "$(which -a curl)" = "" && echo "- 不存在curl 命令" && exit 0
test -e "${0%/*}/github.conf" && rm -rf "${0%/*}/github.conf"

get_IP() {
	curl -skLA "Mozilla/5.0 (Android 11; Mobile; rv:88.0) Gecko/88.0 Firefox/88.0" "$1" | egrep -o '<li>[0-9.]{11,}</li>' | egrep -o -m 1 '[0-9.]{11,}'
}

Check_IP () {
local ip_ass=$(echo $1 | sed "s|https://||g" | cut -d'/' -f2 )
test "$ip_ass" = "" && ip_ass=$(echo $1 | sed "s|https://||g" | cut -d'/' -f1 )
cat <<key>>${0%/*}/github.conf
$(get_IP "$1") $ip_ass
key
}

IP1=`Check_IP https://github.com.ipaddress.com/` 

IP2=`Check_IP https://fastly.net.ipaddress.com/github.global.ssl.fastly.net` 

IP3=`Check_IP https://github.com.ipaddress.com/assets-cdn.github.com` 

IP4=`Check_IP https://github.com.ipaddress.com/gist.github.com` 

IP5=`Check_IP https://githubusercontent.com.ipaddress.com/raw.githubusercontent.com` 

IP6=`Check_IP https://githubassets.com.ipaddress.com/github.githubassets.com` 

IP7=`Check_IP https://github.com.ipaddress.com/customer-stories-feed.github.com` 

IP8=`Check_IP https://github.com.ipaddress.com/codeload.github.com` 

IP9=`Check_IP https://githubusercontent.com.ipaddress.com/avatars.githubusercontent.com` 