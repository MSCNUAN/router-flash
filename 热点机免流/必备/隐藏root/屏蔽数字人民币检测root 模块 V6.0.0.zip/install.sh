#!/bin/sh

cd /data/user/0/cn.gov.pbc.dcep/

chattr -i envc.push

echo "r=0" > /data/user/0/cn.gov.pbc.dcep/envc.push
chattr +i envc.push

ui_print "正在安装模块..."    
ui_print "by 忆雨"
ui_print "无聊瞎写的()"