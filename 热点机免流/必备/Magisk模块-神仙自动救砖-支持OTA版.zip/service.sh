#!/system/bin/sh
#本脚本由搞机助手自动创建
#作者：by：Han | 情非得已c
#请不要试图篡改本脚本，否则一切后果自负，已安装版本：v2021041500(35)
#特别鸣谢Magisk提供服务支持：by topjohnwu


MODDIR=${0%/*}
export PATH="/product/bin:/apex/com.android.runtime/bin:/apex/com.android.art/bin:/system_ext/bin:/system/bin:/system/xbin:/odm/bin:/vendor/bin:/vendor/xbin:/data/user/0/com.gjzs.chongzhi.online/files/usr/busybox:/dev/P5TeaG/.magisk/busybox"
VERSION=$MODDIR/now_version
pre_version=$(cat $VERSION)
now_version=$(getprop ro.system.build.version.incremental)
if [ $pre_version != $now_version ];then
/system/bin/sh $MODDIR/Automatic_brick_rescue2.sh 360
else
/system/bin/sh $MODDIR/Automatic_brick_rescue2.sh 
fi
exit 0

