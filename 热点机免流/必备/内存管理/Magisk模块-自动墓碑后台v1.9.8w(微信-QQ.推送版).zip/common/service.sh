#!/system/bin/sh
MODDIR=${0%/*}
sd=/data/media/0/Android/墓碑日志.log

# 该脚本将在设备开机后作为延迟服务启动
wait_boot_completed() {
  i=10
  while true; do
    sleep $i
    completed=$(getprop sys.boot_completed)
    if [[ "$completed" == "1" ]];then
      return
    fi
  done
}

wait_boot_completed
sleep 3

echo "$(date '+%T') 已经成功开机！" >$sd 
echo "$(date '+%T') 已经开机，并删除旧日志！" >$sd 
#mkdir /dev/freezer
#mount -t cgroup -ofreezer freezer /dev/freezer 
chmod a+x $MODDIR/mb/*.sh
nohup $MODDIR/mb/墓碑启动.sh > /dev/null 2>&1 &
sleep 3

COUNT=$(ps -ef |grep /data/adb/modules/mubei/mb/mb.sh |grep -v "grep" |wc -l)
echo "$COUNT"
if [ $COUNT -eq 0 ]; then
        echo "$(date '+%T') ️开机启动：自动墓碑运行失败！" >>$sd
else
        echo "$(date '+%T') ️开机启动：自动墓碑运行成功！" >>$sd    
fi
