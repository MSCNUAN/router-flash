# Most mods would like it to be enable
SKIPMOUNT=false
#是否安装模块后自动关闭，改为faslse，安装后不会自动勾选启用

# Set to true if you need to load system.prop
PROPFILE=false
#是否使用common/system.prop文件

# Set to true if you need post-fs-data script
POSTFSDATA=false
#是否使用post-fs-data脚本执行文件

# Set to true if you need late_start service script
LATESTARTSERVICE=true
#是否在开机时候允许允许common/service.sh中脚本

##########################################################################################
# Installation Message
##########################################################################################

# Set what you want to show when installing your mod

print_modname() {
	ui_print "*******************************"
	ui_print "     自动墓碑后台APP模块    "
	ui_print "    作者：奋斗的小青年       "
	ui_print "   公众号：有效玩机  首发~！   "
	ui_print "*******************************
	22.8.6号更新内容：
	- 支持QQ和微信推送
	- 修复QQ音乐，喜马拉雅……等后台播放不能识别问题。
	
	- 修复安卓10以下墓碑不生效问题。
	- 微信后台只留推送组件延迟5分钟执行。
	- 新增开机自动删除旧日志功能。
	
	- 修复个别APP卡软件界面。
	- 解决上一版本遗漏APP后台没有进入墓碑。
	- 增加微信识别，后台时只留必要的推送功能。
		
	- 智能识别音频播放APP不进墓碑。
	- 智能识别小窗判断更精准，不闪窗。
	- 增加“墓碑黑名单.conf”可让顽固APP和系统APP进墓碑。
	
	- 进入墓碑APP无延迟，响应迅速。
	- 大幅度降低功耗，做到按需执行。
	- 识别小窗，悬浮窗等APP避免墓碑。
	- 提高开机运行概率，提高稳定性。
	- 该版本恢复后台运行日志请在APP查看。
	- 识别到QQ音乐，网易云音乐播放时不墓碑。来源于@流言乱了蜚语

	- 尝试解决部分手机运行卡顿，解锁不解墓碑的情况。
	- 增加权限解决开机不运行。
	- 采用新命令执行墓碑提高效率，更省电。
	- 修复微博图片bug。
	
	- 统一日志到真实Android路径下。
	- 修复1.8.5分享文件时卡机的BUG。
	- 解决部分手机开机不自启问题。
	- 解决多任务切换APP卡死情况。
	- 由原先home桌面触发为切换APP触发墓碑	。
	- 不在使用crond计时器。
	- 提高代码执行效率。
	- 适配软件客户端软件来自大佬@离音。
	- 去除多余代码，降低资源消耗。
	- 兼容Android6、到Android12+。
	- 独立运行不依赖系统组件。
	- APP离开前台后立即进入墓碑模式。不耗电，不占用CPU，只占运存。
	";
	ui_print "*******************************"
}

##########################################################################################
# Replace list
##########################################################################################

# This is an example
REPLACE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here, it will override the example above
# !DO NOT! remove this if you don't need to replace anything, leave it empty as it is now
SKIPUNZIP=0
REPLACE="
"


##########################################################################################
# Permissions
##########################################################################################
#释放文件，普通shell命令
on_install() {
	ui_print "- 正在释放文件"
	unzip -o "$ZIPFILE" 'common/*' -d $MODPATH >&2
	unzip -o "$ZIPFILE" 'mb/*' -d $MODPATH >&2
	name=$(pm list packages | grep -w package:com.mubei.android)
	mubeiapp="package:com.mubei.android"
	if [[ $name == $mubeiapp ]]
	then
		ui_print "- 墓碑软件端已安装"
	

	else
		ui_print "- 墓碑软件端未安装"
		unzip -o "$ZIPFILE" 'mb.apk' -d /data/local/tmp/ >&2
		#以下安装APK代码来由搞机助手
		export File='/data/local/tmp/mb.apk'
		export Delete_APK='1'
		abort() {
			ui_print "$@" 1>&2
		}
		IFS=$'\n'
		suffix=${File##*.}
		name=`basename "$File"`
		[[ $1 = -s ]] && installer=" -i $installer " || installer=" "
		ui_print "- 正在安装墓碑软件端"
		if [[ ! -f $File ]]; then
			abort "- 文件不存在"
		else
			unzip -l "$File" &>/dev/null
			[[ $? -ne 0 ]] && abort "- $name 不是压缩文件"
		fi
		if [[ $suffix = apk ]]; then
			size=`ls -l "$File" | awk '{print $5}'`
			a="cat \""$File"\" | pm install -r -d -S "$size""$installer" 1> /dev/null"
			eval $a
			result=$?
			if [[ $result = 0 ]]; then
				ui_print "- 墓碑软件端 安装成功"
				[[ $Delete_APK = 1 ]] && rm -f "$File"

			else
				abort -e "- 墓碑软件端 安装失败"
			fi
		fi
	fi
	ui_print "- 已经删除临时文件"


SDK="`getprop ro.build.version.sdk`"
if [[ $SDK -le 28 ]]
	then
	ui_print "- SDK:$SDK 将安装对应版本。"	
    cp -rf /data/adb/modules_update/mubei/mb/mb9.sh /data/adb/modules_update/mubei/mb/mb.sh
    rm -f /data/adb/modules_update/mubei/mb/mb9.sh
	else
	ui_print "- SDK:$SDK 已安装对应版本。"	
     rm -f /data/adb/modules_update/mubei/mb/mb9.sh
fi
}

set_permissions() {

	# The following is default permissions, DO NOT remove
	set_perm_recursive  $MODPATH  0  0  0755  0644

	#设置权限，基本不要去动
}

