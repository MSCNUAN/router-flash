#!/system/bin/sh
MODDIR=${0%/*}

TOP=/dev/cpuset/top-app/cgroup.procs
mb=/data/user/0/com.mubei.android/files/墓碑名单.conf
hmd=/data/adb/modules/mubei/mb/墓碑黑名单.conf
sd=/data/media/0/Android/墓碑日志.log
topl=`cat $TOP`
appsl=''
hmds=`cat $hmd| grep -v '^#' | grep -v '^$'`
SYSAPP=`pm list package -s | awk -F ":" '{print $NF}'`

inotifyd - /dev/cpuset/top-app/tasks | while read f;
do 

top=`cat $TOP`
  if [ "$top" != "$topl" ];then
#安卓10以下机型使用，确保兼容。（无法识别音频）
apps=`dumpsys activity | grep "mResume"| awk '{print $(NF-1)}' | awk -F "/" '{print $1}'`
#apps=`dumpsys window | grep "mFocusedApp" | grep -v "AppWindowToken" | awk '{print $(NF-1)}' | awk -F "/" '{print $1}'`

    if [ "$apps" != "$appsl" ];then
echo -e $apps | tr ' ' '\n'| while read app;do
pkill -18 -f $app
done

 echo -e "$appsl"|tr ' ' '\n'|while read app;do
. /data/user/0/com.mubei.android/files/墓碑名单.conf
BMDS=`echo -e  "$HMD"| grep -v '^#' | grep -v '^$'`
have=`echo -e "$apps" | grep "$app" -c -m 1`
bmd=`echo -e "$BMDS" | grep -o "$app" -c -m 1`
ser=`echo -e "$abbs" | grep "$app" -c -m 1`
sysapp=`echo -e "$SYSAPP" | grep -o "$app" -c -m 1`
hmdapp=`echo -e "$hmds" | grep -o "$app" -c -m 1`
pose="
	com.tencent.mm:sandbox*
	com.tencent.mm:exdevice*
	com.tencent.mm:hotpot*
	com.tencent.mm:TMAssistantDownloadSDKService*
	com.tencent.mm:tools*
	com.tencent.mm:appbrand*
	"	
poseq="
com.tencent.mobileqq:tool*
com.tencent.mobileqq:qzone*
com.tencent.mobileqq:mini*
com.tencent.mobileqq:picture*
com.tencent.mobileqq:TMAssistantDownloadSDKService*
com.tencent.mobileqq:video*
com.tencent.mobileqq:hotpot*
	"	

if [ $have == 0 ];then
if [ $bmd == 0 ];then
if [ $ser == 0 ] ;then
if [ $sysapp == 0 ];then
if [[ $app == "com.tencent.mm" ]] || [[ $app == "com.tencent.mobileqq" ]];then
if [ $app == "com.tencent.mm" ];then
#微信离开后台5分钟后，杀掉多余组件只留消息推送。
     ( sleep 300
     dq=`dumpsys window | grep "mFocusedApp" | grep -v "AppWindowToken" | awk '{print $(NF-1)}' | awk -F "/" '{print $1}'`
     if [ "$dq" == "com.tencent.mm" ];then
         echo "$(date '+%T') 微信$app 取消操作" >>$sd 
     else
         echo "$(date '+%T') 微信$app 只留推送" >>$sd 
         echo -e "$pose"|tr ' ' '\n'|xargs pkill -9 -f
     fi)&
fi
if [ $app == "com.tencent.mobileqq" ];then  
#腾讯QQ离开后台5分钟后，杀掉多余组件只留消息推送。
     ( sleep 300
     dq=`dumpsys window | grep "mFocusedApp" | grep -v "AppWindowToken" | awk '{print $(NF-1)}' | awk -F "/" '{print $1}'`
     if [ "$dq" == "com.tencent.mobileqq" ];then
         echo "$(date '+%T') QQ$app 取消操作" >>$sd 
     else
         echo "$(date '+%T') QQ$app 只留推送" >>$sd 
         echo -e "$poseq"|tr ' ' '\n'|xargs pkill -9 -f
     fi)&
fi
else
echo "$(date '+%T') 离开$app 送入墓碑" >>$sd 
#ps -efo name,pid|grep $app|awk '{print $2}'|while read pid;do echo -17 > /proc/$pid/oom_adj;done
pkill -19 -f $app
fi
fi
fi
fi
fi


if [ $have == 0 ] ;then
if [ $hmdapp == 1 ];then
echo "$(date '+%T') 离开$app 进入墓碑" >>$sd 
pkill -19 -f $app
fi
fi
 done
   fi

appsl=$apps
topl=$top
  fi
done
