#!/system/bin/sh
MODDIR=${0%/*}
nohup $MODDIR/mb.sh > /dev/null 2>&1 &

JB=/data/adb/modules/mubei/mb/mb.sh

COUNT=$(ps -ef |grep $JB |grep -v "grep" |wc -l)
echo " "
if [ $COUNT -eq 0 ]; then
        echo -e "\e[31m没有运行……\n\e[0m"
else
        echo -e "\e[32m正在运行……\n\e[0m"
fi